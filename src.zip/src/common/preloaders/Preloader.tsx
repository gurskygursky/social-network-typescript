import React from "react";
import preloaderImage from "../../assets/image/preloaders/771.svg"
export const Preloader = () => {
    return (
        <div>
            <img src={preloaderImage} alt={"preloader"}/>
        </div>
    )
}