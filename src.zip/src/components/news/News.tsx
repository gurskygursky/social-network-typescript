import React from "react";

export const News = () => {
    return (
        <div>
            News
        </div>

    );
}

