import React from "react";

export const Music = () => {
    return (
        <div>
            Music
        </div>

    );
}

